package com.example.app_sem12_s1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
